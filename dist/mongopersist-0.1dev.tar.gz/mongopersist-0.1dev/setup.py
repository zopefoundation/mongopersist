"""Setup
"""
import os
from setuptools import setup, find_packages

setup (
    name='mongopersist',
    version='0.1dev',
    author = "Stephan Richter",
    author_email = "stephan.richter@gmail.com",
    description = "Mongo Persistence Backend",
    license = "ZPL 2.1",
    keywords = "mongo persistent ",
    classifiers = [
        'Development Status :: 3 - Alpha',
        'Intended Audience :: Developers',
        'Programming Language :: Python',
        'Natural Language :: English',
        'Operating System :: OS Independent'],
    packages = find_packages('src'),
    package_dir = {'':'src'},
    extras_require = dict(
        test = (
            'zope.app.testing',
            'zope.testing',
            ),
        zope = (
            'rwproperty',
            'zope.container',
            ),
        ),
    install_requires = [
        'ZODB3',
        'lru',
        'pymongo',
        'setuptools',
        'zope.dottedname',
        'zope.interface',
    ],
    include_package_data = True,
    zip_safe = False,
    )
