##############################################################################
#
# Copyright (c) 2011 Zope Foundation and Contributors.
# All Rights Reserved.
#
# This software is subject to the provisions of the Zope Public License,
# Version 2.1 (ZPL).  A copy of the ZPL should accompany this distribution.
# THIS SOFTWARE IS PROVIDED "AS IS" AND ANY AND ALL EXPRESS OR IMPLIED
# WARRANTIES ARE DISCLAIMED, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED
# WARRANTIES OF TITLE, MERCHANTABILITY, AGAINST INFRINGEMENT, AND FITNESS
# FOR A PARTICULAR PURPOSE.
#
##############################################################################
"""Mongo Persistent Data Manager"""
from __future__ import absolute_import
import UserDict
import persistent
import pymongo
import pymongo.dbref
import transaction
import zope.interface

from mongopersist import interfaces, pool, serialize

class Root(UserDict.DictMixin):

    def __init__(self, jar):
        self._jar = jar
        db = self._jar._conn[interfaces.ROOT_DATABASE]
        self.collection = db[interfaces.ROOT_COLLECTION]

    def __getitem__(self, key):
        doc = self.collection.find_one({'name': key})
        if doc is None:
            raise KeyError(key)
        return self._jar._reader.get_ghost(doc['ref'])

    def __setitem__(self, key, value):
        dbref = self._jar._writer.store(value)
        value._p_oid = dbref.id
        value._p_mongo_collection = dbref.collection
        value._p_mongo_database = dbref.database
        if self.get(key) is not None:
            del self[key]
        doc = {'ref': dbref, 'name': key}
        self.collection.insert(doc)

    def __delitem__(self, key):
        doc = self.collection.find_one({'name': key})
        coll = self._jar._conn[doc['ref'].database][doc['ref'].collection]
        coll.remove(doc['ref'].id)
        self.collection.remove({'name': key})

    def keys(self):
        return [doc['name']
                for doc in self._jar._db[interfaces.ROOT_COLLECTION].find()]


class MongoDataManager(object):
    zope.interface.implements(interfaces.IMongoDataManager)

    detect_conflicts = False

    def __init__(self, conn, detect_conflicts=None):
        self._conn = conn
        self._reader = serialize.ObjectReader(self)
        self._writer = serialize.ObjectWriter(self)
        self._registered_objects = []
        self._needs_to_join = True
        self._object_cache = {}
        if detect_conflicts is not None:
            self.detect_conflicts = detect_conflicts
        self.transaction_manager = transaction.manager
        self.root = Root(self)

    def reset(self):
        self.__init__(self._conn)

    def setstate(self, obj):
        self._reader.set_ghost_state(obj)

    def oldstate(self, obj, tid):
        # I cannot find any code using this method. Also, since we do not keep
        # version history, we always raise an error.
        raise KeyError(tid)

    def register(self, obj):
        if self._needs_to_join:
            self.transaction_manager.get().join(self)
            self._needs_to_join = False

        if obj is not None and obj not in self._registered_objects:
            self._registered_objects.append(obj)

    def abort(self, transaction):
        self.reset()

    def commit(self, transaction):
        if not self.detect_conflicts:
            return
        # Check each modified object to see whether Mongo has a new version of
        # the object.
        for obj in self._registered_objects:
            db_name, coll_name = self._writer.get_collection_name(obj)
            coll = self._conn[db_name][coll_name]
            new_doc = coll.find_one(obj._p_oid, fields=('_py_serial',))
            if new_doc.get('_py_serial', 0) != serialize.u64(obj._p_serial):
                raise interfaces.ConflictError(
                    None, obj,
                    (new_doc.get('_py_serial', 0),
                     serialize.u64(obj._p_serial)))

    def tpc_begin(self, transaction):
        pass

    def tpc_vote(self, transaction):
        pass

    def tpc_finish(self, transaction):
        written = []
        for obj in self._registered_objects:
            if getattr(obj, '_p_mongo_sub_object', False):
                obj = obj._p_mongo_doc_object
            if obj in written:
                continue
            self._writer.store(obj)
            written.append(obj)
        self.reset()

    def tpc_abort(self, transaction):
        self.abort(transaction)

    def sortKey(self):
        return ('MongoDataManager', 0)


@zope.interface.implementer(interfaces.IMongoDataManager)
@zope.component.adapter(None)
def get_mongo_data_manager(context=None):
    try:
        return pool.LOCAL.data_manager
    except AttributeError, err:
        pass
    conn = pool.CONNECTION_POOL.connection
    db = conn[interfaces.DEFAULT_DATABASE]
    dm = pool.LOCAL.data_manager = MongoDataManager(db)
    return dm
